
def endgame(tablerojugador, tablero_computadora):
    if 'O' in tablero_computadora:
        print("Enhorabuena, has derrotado a la computadora!!")
        print('\U0001F4AA', '\U0001F38A', '\U0001F389')


    elif 'O' in tablerojugador:
        print("La computadora te derrotó :`(")
        print('\U0001F9BE')
