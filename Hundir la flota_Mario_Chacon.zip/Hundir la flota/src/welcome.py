import jugador1


def welcome():
      print('Bienvenidos jugadores!\n'
          'Has entrado en Hundir la Flota.\n'
          'El juego consiste en hundir los barcos del oponente antes que el oponente destruye los tuyos introduciendo coordenadas.')
      print('\U0001F600', '\U0001F9E0','\U0001F6F8')
      jugador = input('¡Por favor introduzca su nombre y prepárese para la batalla espacial! : ')
      return jugador

#     jugador1.jugador1(tablerojugador, tablerocomputadora, tablerovacio1, tablerovacio2) tablerojugador, tablerocomputadora, tablerovacio1, tablerovacio2

